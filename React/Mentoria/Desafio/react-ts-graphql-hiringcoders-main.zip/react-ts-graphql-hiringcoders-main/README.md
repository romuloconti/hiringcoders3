# React e GraphQL


## Veja o projeto no online:
[clique aqui](https://rickandmorty-ts-graphql.vercel.app/)

### Para clonar o projeto:
`git clone https://github.com/mrdouglasmorais/react-ts-graphql-hiringcoders`

### Para instalar as dependências:
`yarn`

### Para iniciar localmente:
`yarn start`

### Documentação de API para
[clique aqui](https://rickandmortyapi.com/)

### PLayground GraphQL
[clique aqui](https://rickandmortyapi.com/graphql)

### Professor Douglas Morais

## Hiring Coders | Gama Academy