export const randomPage: number = Number((Math.random() * 33 + 1).toFixed(0));
