import './App.css';
import Cards from './components/cards';

function App() {
  return (
    <div className="App">
      <Cards key={'key'} />
    </div>
  );
}

export default App;
